﻿<?php

require("backend/connection.php");

//Add the user details to the database
// $add_visitor = "INSERT INTO `visitors_detail` (`user_ip`, `user_agent`) VALUES ('$_SERVER[REMOTE_ADDR]', '$_SERVER[HTTP_USER_AGENT]')";

// mysqli_query($conn,$add_visitor);


?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Welcome to National AT Bank</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.svg" rel="icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Montserrat:300,400,500,700" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
   <!-- link for icon  -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">


  <!-- =======================================================
  * Template Name: NewBiz - v4.0.1
  * Template URL: https://bootstrapmade.com/newbiz-bootstrap-business-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>
  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex justify-content-between">
      <img src="images/logo.jpeg" width="60" height="60" class="d-inline-block align-left" alt="">
      <div class="logo">

        <h1><a href="index.php">NATIONAL AT BANK</a></h1>
        <!--<a href="index.php"><img src="images/bg-login2.jpg" alt="Logo" class="img-fluid"><b>&nbsp;&nbsp;NATIONAL AT BANK</b></a>-->
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
          <li><a class="nav-link scrollto" href="#about">About</a></li>
          <li><a class="nav-link scrollto" href="#services">Notices</a></li>
          <li><a class="nav-link scrollto" href="#team">Team</a></li>
          <li><a class="nav-link scrollto" href="#contact">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- #header -->


  <section id="hero" class="clearfix">
    <div class="container" data-aos="fade-up">

      <div class="hero-img" data-aos="zoom-out" data-aos-delay="200">
        <img src="" alt="" class="img-fluid">
      </div>

      <div>

        <!DOCTYPE html>
        <html>

        <head>
          <title>Banking</title>
          <?php require 'assets/autoloader.php'; ?>
          <?php require 'assets/function.php'; ?>
          <?php
          $con = new mysqli('localhost', 'root', '', 'mybank');


          $error = "";
          if (isset($_POST['userLogin'])) {
            $error = "";
            $user = $_POST['email'];
            $pass = $_POST['password'];

            $result = $con->query("select * from userAccounts where email='$user' AND password='$pass'");
            if ($result->num_rows > 0) {
              session_start();
              $data = $result->fetch_assoc();
              $_SESSION['userId'] = $data['id'];
              $_SESSION['user'] = $data;
              header('location:index.php');
            } else {
              $error = "<div class='alert alert-warning text-center rounded-0'>Username or password wrong try again!</div>";
            }
          }
          if (isset($_POST['cashierLogin'])) {
            $error = "";
            $user = $_POST['email'];
            $pass = $_POST['password'];

            $result = $con->query("select * from login where email='$user' AND password='$pass'");
            if ($result->num_rows > 0) {
              session_start();
              $data = $result->fetch_assoc();
              $_SESSION['cashId'] = $data['id'];
              //$_SESSION['user'] = $data;
              header('location:cindex.php');
            } else {
              $error = "<div class='alert alert-warning text-center rounded-0'>Username or password wrong try again!</div>";
            }
          }
          if (isset($_POST['managerLogin'])) {
            $error = "";
            $user = $_POST['email'];
            $pass = $_POST['password'];

            $result = $con->query("select * from login where email='$user' AND password='$pass' AND type='manager'");
            if ($result->num_rows > 0) {
              session_start();
              $data = $result->fetch_assoc();
              $_SESSION['managerId'] = $data['id'];
              //$_SESSION['user'] = $data;
              header('location:mindex.php');
            } else {
              $error = "<div class='alert alert-warning text-center rounded-0'>Username or password wrong try again!</div>";
            }
          }

          ?>
        </head>


        <br>

        <br>
        <?php echo $error ?>
        <br>
        <div id="accordion" role="tablist" class="w-25 float-center black" style="margin-right: 222px">
          <br>
          <h4 class="text-center text-white">Select Your Session</h4>
          <div class="card rounded-0">
            <div class="card-header" role="tab" id="headingOne">
              <h5 class="mb-0">
                <a style="text-decoration: none;" data-toggle="collapse" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">

                </a>
              </h5>
            </div>

            <div id="collapseOne" class="collapse" role="tabpanel" aria-labelledby="headingOne" data-parent="#accordion">
              <div class="card-body">
                <form method="POST">
                  <input type="email" value="some@gmail.com" name="email" class="form-control" required placeholder="Enter Email">
                  <input type="password" name="password" value="some" class="form-control" required placeholder="Enter Password">
                  <button type="submit" class="btn btn-primary btn-block btn-sm my-1" name="userLogin">Enter </button>
                </form>
              </div>
            </div>
          </div>
          <div class="card rounded-0">
            <div class="card-header" role="tab" id="headingTwo">
              <h5 class="mb-0">
                <a class="collapsed btn btn-outline-success btn-block" data-toggle="collapse" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                  Manager Login
                </a>
              </h5>
            </div>
            <div id="collapseTwo" class="collapse" role="tabpanel" aria-labelledby="headingTwo" data-parent="#accordion">
              <div class="card-body">
                <form method="POST">
                  <input type="email" value="manager@manager.com" name="email" class="form-control" required placeholder="Enter Email">
                  <input type="password" name="password" value="manager" class="form-control" required placeholder="Enter Password">
                  <button type="submit" class="btn btn-primary btn-block btn-sm my-1" name="managerLogin">Enter </button>
                </form>
              </div>
            </div>
          </div>
          <div class="card rounded-0">
            <div class="card-header" role="tab" id="headingThree">
              <h5 class="mb-0">
                <a class="collapsed btn btn-outline-success btn-block" data-toggle="collapse" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                  Employee Login
                </a>
              </h5>
            </div>
            <div id="collapseThree" class="collapse" role="tabpanel" aria-labelledby="headingThree" data-parent="#accordion">
              <div class="card-body">
                <form method="POST">
                  <input type="email" value="cashier@cashier.com" name="email" class="form-control" required placeholder="Enter Email">
                  <input type="password" name="password" value="cashier" class="form-control" required placeholder="Enter Password">
                  <button type="submit" class="btn btn-primary btn-block btn-sm my-1" name="cashierLogin">Enter </button>
                </form>
              </div>
            </div>
          </div>
        </div>


  </section><!-- End Hero Section -->

  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about">
      <div class="container" data-aos="fade-up">

        <header class="section-header">
          <h3>About Us</h3>
          <p>NATIONAL AT is an Indian multinational, public sector banking and financial services statutory body, fostering the nation’s 2.6 trillion-dollar economy and serving the hopes of its vast population.</p>
        </header>

        <div class="row about-container">

          <div class="col-lg-6 content order-lg-1 order-2">
            <p>
              For NATIONAL AT, the interests of the common man havealways remained at the core of its business.With a customer-centric approach, the Bankhas designed products and services to meet the expectations of the financial life cycle of its valued clientele. Keeping pace with the transforming landscape of the Indian economy, NATIONAL AT has broadened its digital base in the recent years.
            </p>

            <div class="icon-box" data-aos="fade-up" data-aos-delay="100">
              <div class="icon"><i class="bi bi-card-checklist"></i></div>
              <h4 class="title"><a href="">Quick Start Account</a></h4>
              <p class="description">Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi</p>
            </div>

            <div class="icon-box" data-aos="fade-up" data-aos-delay="200">
              <div class="icon"><i class="bi bi-brightness-high"></i></div>
              <h4 class="title"><a href="">Instant Fund Transfer</a></h4>
              <p class="description">Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum</p>
            </div>

            <div class="icon-box" data-aos="fade-up" data-aos-delay="300">
              <div class="icon"><i class="bi bi-calendar4-week"></i></div>
              <h4 class="title"><a href="">Dolor Sitema</a></h4>
              <p class="description">Minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat tarad limino ata</p>
            </div>

          </div>

          <div class="col-lg-6 background order-lg-2" data-aos="zoom-in">
            <img src="assets/img/about-img.svg" class="img-fluid" alt="">
          </div>
        </div>



      </div>
    </section><!-- End About Section -->

    <!-- ======= servies Section ======= -->
    <section id="services" class="section-bg">
      <div class="container" data-aso="">

        <header class="section-header">
          <h3>SERVICE</h3>
        </header>



        <div class="testimonials-slider swiper-container">
          <div class="swiper-wrapper">

            <div class="swiper-slide">
              <img src="images/testimonial-1.jpeg" class="testimonial-img" alt="center">
            </div>

            <div class="swiper-slide">
              <img src="images/testimonial-2.jpeg" class="testimonial-img" alt="center">
            </div>

            <div class="swiper-slide">
              <img src="images/testimonial-3.jpeg" class="testimonial-img" alt="center">
            </div>

            <div class="swiper-slide">
              <img src="images/testimonial-4.jpeg" class="testimonial-img" alt="center">
            </div>

          </div>
          <div class="swiper-pagination"></div>
        </div>

      </div>
      </div>

      </div>
    </section><!-- End Testimonials Section -->


    <center>
      <!-- ======= Team Section ======= -->
      <section id="team">
        <div class="container" data-aos="fade-up">
          <div class="section-header">
            <h3>Team</h3>
            <p>Meet some of our people as they share their interesting journey of growth and development in the Bank.</p>
          </div>

          <div class="row">

            <div class="col-lg-3 col-md-6" data-aos="zoom-out" data-aos-delay="80">
              <div class="member">
                <img src="images/team-1.jpeg" class="img-fluid" alt="center">
                <div class="member-info">
                  <div class="member-info-content">
                    <h4>ABHILASH G R</h4>
                    <span> MANAGER</span>
                    <div class="social">
                      <a href=""><i class="bi bi-twitter"></i></a>
                      <a href=""><i class="bi bi-facebook"></i></a>
                      <a href="https://www.instagram.com/ABHI_GR /"><i class="bi bi-instagram"></i></a>
                      <a href=""><i class="bi bi-linkedin"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-lg-3 col-md-6" data-aos="zoom-out" data-aos-delay="200">
              <div class="member">
                <img src="images/team-2.jpeg" class="img-fluid" alt="center">
                <div class="member-info">
                  <div class="member-info-content">
                    <h4>TUSHAR KUMAR</h4>
                    <span>ACCOUNTANT</span>
                    <div class="social">
                      <a href=""><i class="bi bi-twitter"></i></a>
                      <a href=""><i class="bi bi-facebook"></i></a>
                      <a href="https://www.instagram.com/in/TUSHAR/"><i class="bi bi-instagram"></i></a>
                      <a href="https://www.linkedin.com/in/TUSHAR/"><i class="bi bi-linkedin"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>



            <div class="col-lg-3 col-md-6" data-aos="zoom-out" data-aos-delay="400">
              <div class="member">
                <img src="images/team-4.jpeg" class="img-fluid" alt="center">
                <div class="member-info">
                  <div class="member-info-content">
                    <h4>HARISH</h4>
                    <span>CTO</span>
                    <div class="social">
                      <a href=""><i class="bi bi-twitter"></i></a>
                      <a href="https://www.facebook.com/ABHILASH.GR"><i class="bi bi-facebook"></i></a>
                      <a href="https://www.instagram.com/ABHILASH.GR/"><i class="bi bi-instagram"></i></a>
                      <a href=""><i class="bi bi-linkedin"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>


            <div class="col-lg-3 col-md-6" data-aos="zoom-out" data-aos-delay="400">
              <div class="member">
                <img src="images/team-4.jpeg" class="img-fluid" alt="center">
                <div class="member-info">
                  <div class="member-info-content">
                    <h4>SHASHI</h4>
                    <span>PRODUCT MANAGER</span>
                    <div class="social">
                      <a href=""><i class="bi bi-twitter"></i></a>
                      <a href="https://www.facebook.com/ABHILASH.GR"><i class="bi bi-facebook"></i></a>
                      <a href="https://www.instagram.com/ABHILASH.GR/"><i class="bi bi-instagram"></i></a>
                      <a href=""><i class="bi bi-linkedin"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </section><!-- End Team Section -->
    </center>

    <!-- ======= Contact Section ======= -->

    <section id="contact" class="py-5 bg-light">
      <div class="container" data-aos="fade-up">

        <div class="section-header text-center mb-5">
          <h3 class="fw-bold">Get in Touch</h3>
          <p class="text-muted">We’d love to hear from you. Reach out using any of the options below.</p>
        </div>

        <div class="row g-4">
          <!-- Contact Info -->
          <div class="col-lg-5">
            <div class="p-4 rounded-4 shadow-sm bg-white h-100">

              <div class="d-flex align-items-center mb-4">
                <i class="bi bi-geo-alt fs-4 text-primary me-3"></i>
                <p class="mb-0 fw-semibold">National AT BANK Jayanagar</p>
              </div>

              <div class="d-flex align-items-center mb-4">
                <i class="bi bi-envelope fs-4 text-danger me-3"></i>
                <p class="mb-0">NATIONALAT@gmail.com</p>
              </div>

              <div class="d-flex align-items-center mb-4">
                <i class="bi bi-phone fs-4 text-success me-3"></i>
                <p class="mb-0">+91 8660331673</p>
              </div>

              <div class="d-flex align-items-center mb-4">
                <i class="bi bi-whatsapp fs-4 text-success me-3"></i>
                <p class="mb-0">+91 9066376347</p>
              </div>

              <div class="d-flex align-items-center mb-4">
                <i class="bi bi-twitter fs-4 text-info me-3"></i>
                <p class="mb-0">@NationalATBank</p>
              </div>

              <div class="d-flex align-items-center">
                <i class="bi bi-instagram fs-4 text-danger me-3"></i>
                <p class="mb-0">@NationalATBank</p>
              </div>

            </div>
          </div>

          <!-- Contact Form + Map -->
          <div class="col-lg-7">
            <div class="p-4 rounded-4 shadow-sm bg-white">
              <form action="save_contact.php" method="POST">
                <div class="row g-3 mb-3">
                  <div class="col-md-6">
                    <input type="text" name="name" class="form-control" placeholder="Your Name" required>
                  </div>
                  <div class="col-md-6">
                    <input type="email" name="email" class="form-control" placeholder="Your Email" required>
                  </div>
                </div>
                <div class="mb-3">
                  <input type="text" name="subject" class="form-control" placeholder="Subject" required>
                </div>
                <div class="mb-3">
                  <textarea name="message" class="form-control" rows="4" placeholder="Message" required></textarea>
                </div>
                <button type="submit" class="btn btn-primary px-4 rounded-pill">Send Message</button>
              </form>


              <!-- Map -->
              <div class="mt-4">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3888.7381509160873!2d77.57617987358813!3d12.924543915911238!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae15bdb2750e53%3A0x7098fbc027b4bfe!2sThe%20National%20Degree%20College%20Jayanagar!5e0!3m2!1sen!2sin!4v1756912702975!5m2!1sen!2sin"
                  width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy">
                </iframe>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>
    <!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-4 col-md-6 footer-info">
            <h3>NATIONAL AT BANK</h3>
            <p>NATIONAL AT BANK was formed in 1955 it as nation’s 2.6 trillion-dollar economy and serving the hopes of its vast population. </p>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><a href="pages/privacy-policy.html">Privacy & policy</a></li>
              <li><a href="pages/terms-and-conditions.html">Terms & conditions</a></li>
              <li><a href="pages/about.html">About us</a></li>

            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-contact">
            <h4>Contact Us</h4>
            <p>
              NATIONAL COLLEGE <br>
              JAYANAGAR<br>
              BANGLORE <br>
              <strong>Phone:</strong> 8660331673<br>
              <strong>Email:</strong>NATIONALAT@gmail.com<br>
            </p>
          </div>


          <div class="col-lg-3 col-md-6 footer--newsletter">
            <h4>social links</h4>
            <a href="https://www.youtube.com/c/national" class="twitter"><i class="bi bi-youtube"></i></a>
            <a href="https://wwwfacebook.com" class="facebook"><i class="bi bi-facebook"></i></a>
            <a href="https://www.instagram.com/national" class="instagram"><i class="bi bi-instagram"></i></a>
            <a href="https://www.linkedin.com/in/national/" class="linkedin"><i class="bi bi-linkedin"></i></a>
          </div>

        </div>


      </div>
    </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; 2021 Copyright <strong>NATIONAL AT BANK</strong>. All Rights Reserved
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/purecounter/purecounter.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>