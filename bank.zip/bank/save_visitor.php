<?php
// Database connection
$servername = "localhost";
$username   = "root";    // default XAMPP user
$password   = "";        // default XAMPP password is empty
$dbname     = "mybank";  // your existing database

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Collect visitor details
$user_ip    = $_SERVER['REMOTE_ADDR'];
$user_agent = $_SERVER['HTTP_USER_AGENT'];

// Insert visitor details into table
$add_visitor = "INSERT INTO visitors_detail (user_ip, user_agent) 
                VALUES ('$user_ip', '$user_agent')";

if ($conn->query($add_visitor) === TRUE) {
    // Optional: You can echo something for testing
    // echo "Visitor logged successfully!";
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>
sav