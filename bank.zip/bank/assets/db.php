<?php
session_start();   // must be the first line before using $_SESSION

$con = new mysqli('localhost', 'root', '', 'mybank');
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

define('bankName', 'NATIONAL AT Bank');

// ✅ Check if session id exists
if (isset($_SESSION['id'])) {
    $id = intval($_SESSION['id']); // cast to int for safety

    $ar = $con->query("SELECT * FROM userAccounts 
                       JOIN branch ON userAccounts.branch = branch.branchId 
                       WHERE userAccounts.id = '$id'");

    $userData = $ar->fetch_assoc();
} else {
    // No session yet → don’t run query here
    $userData = null;
}
?>
<script type="text/javascript">
$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})
</script>
