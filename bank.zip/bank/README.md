# Swift Bank
## The free and open source bank management system

[![Build Status](https://travis-ci.org/joemccann/dillinger.svg?branch=master)](https://youtu.be/_n7Z97n_neg)

This is my first php project. You can make changes and make a good working BMS. I found that lot's of new bank have the problem. They don't have a good working management system. So together we will make them help. 

- Take into consideration that it is not a actual Swift Bank 
- See more on my youtube channel
- ✨Contribue if possible

## Features

- Employee can add new customers
- Manager can add employee's as well as customers
- Interactive dashboard for manager
- Special analytics for bank manager
- This system only allow one user in one browser at the same time


## Installation

Just import the SwiftBank.sql file into your local database.
And that's it guys!
You are ready to go.

#### Note
All the *.sh files are only use to start localserver on linux based local system.
You may delete this after push.
